<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
        <?php if(auth()->guard()->check()): ?>
            <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                 <?php $__env->slot('trigger', null, []); ?> 
                    <span class="inline-flex rounded-md">
                        <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-600 bg-white hover:text-gray-900 focus:outline-none transition">
                            <?php echo e(Auth::user()->name); ?>

                            <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                            </svg>
                        </button>
                    </span>
                 <?php $__env->endSlot(); ?>

                <!--dropdown-->
                 <?php $__env->slot('content', null, []); ?> 
                    <form method="GET" action="<?php echo e(route('profile.show')); ?>">
                        <button type="submit" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            <?php echo e(__('Profile')); ?>

                        </button>
                    </form>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                            <?php echo e(__('Log Out')); ?>

                        </button>
                    </form>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
            <!--tlacitka login register-->
        <?php else: ?>
            <div class="flex flex-row items-center justify-start gap-3">
                <a href="<?php echo e(route('login')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md shadow focus:outline-none">
                    <?php echo e(__('Log in')); ?>

                </a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="inline-flex items-center px-4 py-2 border border-blue-600 text-blue-700 bg-white hover:bg-blue-50 text-sm font-medium rounded-md shadow-sm focus:outline-none">
                        <?php echo e(__('Register')); ?>

                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <!--novej prispevek-->
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg p-6 border-t-4 border-indigo-500">
                <h3 class="font-bold text-lg mb-4">Nahrát nový příspěvek</h3>
                <?php if(auth()->guard()->check()): ?>
                    <form method="POST" action="<?php echo e(route('prispevky.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-6">
                            <label for="fotka" class="block text-sm font-medium text-gray-700 mb-2">Vyberte fotku:</label>
                            <input type="file" name="fotka" id="fotka" accept="image/*" required class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                        </div>
                        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded shadow-md transition transform hover:-translate-y-0.5">🚀 Odeslat příspěvek</button>
                    </form>
                <?php else: ?>
                    <div class="p-4 bg-yellow-50 border border-yellow-200 rounded text-yellow-800">
                        Pro nahrání příspěvku se prosím <a href="<?php echo e(route('login')); ?>" class="text-blue-600 underline font-bold">přihlaste</a>.
                    </div>
                <?php endif; ?>
            </div>
            <!--vypis prispevku-->
            <div class="grid gap-6">
                <?php $__currentLoopData = $prispevky->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prispevek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white border rounded-lg shadow-sm p-6">
                        <div class="flex justify-between items-center mb-2">
                            <p class="font-bold text-lg"><?php echo e($prispevek->user->name ?? 'Smazaný uživatel'); ?></p>
                            <span class="text-xs text-gray-400"><?php echo e($prispevek->created_at?->diffForHumans() ?? 'Neznámé datum'); ?></span>
                        </div>
                        
                        <img src="<?php echo e(asset('storage/' . $prispevek->fotka)); ?>" alt="Příspěvek" class="w-full h-64 object-cover rounded-md mb-4 bg-gray-100">

                        <!--lajky-->
                        <div class="flex items-center gap-3 mb-4 border-b pb-4">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(!$prispevek->isLikedByUser(auth()->id())): ?>
                                    <form method="POST" action="<?php echo e(route('prispevky.like', $prispevek->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition">
                                            👍 Like
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('prispevky.like', $prispevek->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition">
                                            👎 Odebrat lajk
                                        </button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                            <span class="text-gray-600 font-medium"><?php echo e($prispevek->lajky); ?> lajků</span>
                        </div>
                        <!--komentare-->
                        <div>
                            <h4 class="font-semibold text-gray-800 mb-3">Komentáře</h4>

                            <div class="space-y-3 mb-4 max-h-60 overflow-y-auto">
                                <?php $__empty_1 = true; $__currentLoopData = $prispevek->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komentar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="border rounded p-3 bg-gray-50">
                                        <div class="flex justify-between items-baseline">
                                            <strong class="text-sm"><?php echo e($komentar->user->name ?? 'Smazaný uživatel'); ?></strong>
                                            <span class="text-xs text-gray-500"><?php echo e($komentar->created_at?->diffForHumans()); ?></span>
                                        </div>
                                        <p class="mt-1 text-gray-800"><?php echo e($komentar->text); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-sm text-gray-500 italic">Zatím žádné komentáře.</p>
                                <?php endif; ?>
                            </div>
                            <!--postovani komentu-->
                            <?php if(auth()->guard()->check()): ?>
                                <form method="POST" action="<?php echo e(route('prispevky.comment', $prispevek->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="flex gap-2">
                                        <textarea name="text" rows="1" class="flex-1 border rounded p-2 text-sm focus:ring-blue-500 focus:border-blue-500" placeholder="Napište komentář..." required></textarea>
                                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-lg transition whitespace-nowrap">Odeslat</button>
                                    </div>
                                    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-xs mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </form>
                            <?php else: ?>
                                <p class="text-sm text-gray-600">Pro přidání komentáře se <a href="<?php echo e(route('login')); ?>" class="underline text-blue-600">přihlaste</a>.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH D:\Škola\vejska\WTV\prace\meme\resources\views/welcome.blade.php ENDPATH**/ ?>